---
name: iptv-auto-test
description: IPTV 频道自动测试技能。三轮测试机制自动检测失效频道、删除无效源、恢复可用源，并触发 APK 重建发布。支持 ffmpeg 并发测试、白名单跳过、版本号自动递增。
---

# IPTV 频道自动测试技能

## 功能概述

自动测试 IPTV 直播源可用性，三轮测试机制确保不误删频道：

- **第一轮（全量标记）**：测试所有频道 30 秒，不能播放的写入待删列表（不删除）
- **第二轮（复测删除）**：复测待删频道，仍不能播放的从频道列表删除并记录到已删列表
- **第三轮（复测恢复+构建）**：复测已删频道，恢复正常的加回频道列表，递增版本号并构建新 APK

## 定时执行

| 北京时间 | UTC 时间 | 轮次 | 说明 |
|---------|---------|------|------|
| 12:00 | 04:00 | round1 | 全量测试所有频道 |
| 18:00 | 10:00 | round2 | 复测待删频道，删除失效 |
| 20:00 | 12:00 | round3 | 复测已删频道，恢复+构建 |

## 文件说明

```
tv-proxy/
├── .github/workflows/
│   └── auto-test-channels.yml    # GitHub Actions 工作流
├── tools/
│   ├── test_channels.py          # 测试脚本（核心）
│   ├── pending-delete.json       # 待删列表（自动生成）
│   ├── deleted.json              # 已删列表（自动生成）
│   ├── test-skip.json            # 白名单（手动维护，永不删除）
│   └── version.json              # 版本信息
└── apk-native/app/
    ├── build.gradle              # 版本号配置
    └── src/main/assets/
        └── channels.json         # 频道列表
```

## 使用方法

### 1. 手动触发某轮测试

```bash
# 触发第一轮（全量测试）
gh workflow run auto-test-channels.yml -f round=round1

# 触发第二轮（复测删除）
gh workflow run auto-test-channels.yml -f round=round2

# 触发第三轮（复测恢复+构建）
gh workflow run auto-test-channels.yml -f round=round3
```

### 2. 本地运行测试脚本

```bash
# 安装 ffmpeg
sudo apt-get install -y ffmpeg

# 第一轮：全量测试
python3 tools/test_channels.py --mode round1 \
  --input apk-native/app/src/main/assets/channels.json \
  --pending tools/pending-delete.json \
  --skip-file tools/test-skip.json \
  --duration 30 --workers 10

# 第二轮：复测删除
python3 tools/test_channels.py --mode round2 \
  --input apk-native/app/src/main/assets/channels.json \
  --output apk-native/app/src/main/assets/channels.json \
  --pending tools/pending-delete.json \
  --deleted tools/deleted.json \
  --duration 30 --workers 10

# 第三轮：复测恢复+递增版本号
python3 tools/test_channels.py --mode round3 \
  --input apk-native/app/src/main/assets/channels.json \
  --output apk-native/app/src/main/assets/channels.json \
  --deleted tools/deleted.json \
  --duration 30 --workers 10 \
  --version-json tools/version.json \
  --build-gradle apk-native/app/build.gradle
```

### 3. 白名单配置

创建 `tools/test-skip.json`，其中的分类和频道永不测试不删除：

```json
{
  "categories": ["潮汕频道"],
  "channels": ["CCTV-1", "CCTV-13"]
}
```

## 前置条件

### GitHub Secrets

| Secret 名称 | 说明 |
|------------|------|
| `GITHUB_TOKEN` | 自动提供，用于提交代码和上传 release |
| `PUSH_TOKEN` | Personal Access Token，用于跨仓库推送 APK |
| `RELEASE_TOKEN` | 用于发布到 tv-release 仓库 |

### 仓库结构

- `tv-proxy`：主仓库，包含源码和工作流
- `tv-release`：发布仓库，存放 APK 和 version.json（供 APP OTA 更新）

## 测试原理

使用 ffmpeg 测试每个频道 URL：

```bash
ffmpeg -i <url> -t 30 -f null - -y -loglevel error -nostats
```

- 返回码 0 = 可播放
- 返回码非 0 = 不能播放
- 超时 = 不能播放

每个频道测试所有备选 URL，任一成功即通过。10 个并发测试，100 个频道约需 5 分钟。
