#!/usr/bin/env python3
"""
IPTV 频道自动测试脚本（三轮测试）

round1（北京时间12:00）: 全量测试所有频道30秒，不能播放的写入待删列表（不删除）
round2（北京时间18:00）: 复测待删列表，仍不能播放的从频道列表删除并记录到已删列表
round3（北京时间20:00）: 复测已删列表，恢复正常的加回频道列表，递增版本号供构建新APK

每轮结果都提交到仓库，下一轮运行时自动使用最新频道列表（新增频道由round1全量测试覆盖）。

用法:
  # 第一轮
  python3 test_channels.py --mode round1 \
    --input channels.json --pending pending-delete.json --duration 30
  # 第二轮
  python3 test_channels.py --mode round2 \
    --input channels.json --output channels.json \
    --pending pending-delete.json --deleted deleted.json --duration 30
  # 第三轮
  python3 test_channels.py --mode round3 \
    --input channels.json --output channels.json \
    --deleted deleted.json --duration 30 \
    --version-json version.json --build-gradle build.gradle
"""

import argparse
import json
import re
import subprocess
import sys
import os
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed


def test_url(url, duration):
    """测试单个URL能否持续播放指定时长"""
    try:
        cmd = ["ffmpeg", "-i", url, "-t", str(duration), "-f", "null", "-",
               "-y", "-loglevel", "error", "-nostats"]
        result = subprocess.run(cmd, timeout=duration + 10,
                                capture_output=True, text=True)
        if result.returncode == 0:
            return True, "OK"
        err = result.stderr.strip().split("\n")[-1] if result.stderr else "unknown error"
        return False, err[:80]
    except subprocess.TimeoutExpired:
        return False, "timeout"
    except Exception as e:
        return False, str(e)[:80]


def test_channel(ch, duration):
    """测试频道所有线路，任一成功即通过"""
    urls = ch.get("urls", [])
    if not urls:
        return False, "no url"
    last_msg = "unknown"
    for url in urls:
        ok, msg = test_url(url, duration)
        if ok:
            return True, "OK"
        last_msg = msg
    return False, last_msg


def run_tests(channel_map, duration, workers):
    """并发测试频道，channel_map: {(分类, 频道名): 频道对象}"""
    results = {}
    done = 0
    total = len(channel_map)
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(test_channel, ch, duration): key
                   for key, ch in channel_map.items()}
        for future in as_completed(futures):
            key = futures[future]
            ok, msg = future.result()
            results[key] = (ok, msg)
            done += 1
            status = "✓" if ok else "✗"
            print(f"  [{done}/{total}] {status} {key[1]} - {msg}", flush=True)
    return results


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_skip_list(skip_path):
    """加载白名单：跳过测试的分类和频道（永不删除）"""
    skip_cats, skip_channels = set(), set()
    if skip_path and os.path.exists(skip_path):
        data = load_json(skip_path)
        skip_cats = set(data.get("categories", []))
        skip_channels = set(data.get("channels", []))
    return skip_cats, skip_channels


def save_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def run_round1(args):
    data = load_json(args.input)
    skip_cats, skip_channels = load_skip_list(args.skip_file)
    channel_map = {}
    skipped = []
    for cat in data.get("categories", []):
        for ch in cat["channels"]:
            if cat["name"] in skip_cats or ch["name"] in skip_channels:
                skipped.append((cat["name"], ch["name"]))
                continue
            channel_map[(cat["name"], ch["name"])] = ch
    for cat_name, ch_name in skipped:
        print(f"  [跳过] [{cat_name}] {ch_name}（白名单，不测试不删除）")
    total = len(channel_map)
    print(f"[第一轮] 开始测试 {total} 个频道，每个 {args.duration} 秒，并行 {args.workers} 个...")
    print(f"预计耗时: {total * args.duration / args.workers / 60:.1f} 分钟")
    results = run_tests(channel_map, args.duration, args.workers)
    failed = [(k, msg) for k, (ok, msg) in results.items() if not ok]
    pending = {
        "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "channels": [{"category": k[0], "name": k[1], "reason": msg}
                     for k, msg in failed]
    }
    save_json(args.pending, pending)
    print()
    print(f"[第一轮] 完成: 总计 {total}，正常 {total - len(failed)}，待复测 {len(failed)}")
    for k, msg in failed:
        print(f"  待复测: [{k[0]}] {k[1]} ({msg})")
    print(f"待删列表已保存: {args.pending}（未删除任何频道）")


def run_round2(args):
    if not os.path.exists(args.pending):
        print("[第二轮] 待删列表不存在，跳过")
        return
    pending = load_json(args.pending)
    pending_list = pending.get("channels", [])
    if not pending_list:
        print("[第二轮] 待删列表为空，跳过")
        return
    data = load_json(args.input)
    lookup = {}
    for cat in data.get("categories", []):
        for ch in cat["channels"]:
            lookup[(cat["name"], ch["name"])] = ch
    to_test = {}
    for item in pending_list:
        key = (item["category"], item["name"])
        if key in lookup:
            to_test[key] = lookup[key]
    print(f"[第二轮] 复测 {len(to_test)}/{len(pending_list)} 个待删频道，每个 {args.duration} 秒...")
    results = run_tests(to_test, args.duration, args.workers)
    removed, recovered = [], []
    for item in pending_list:
        key = (item["category"], item["name"])
        if key not in lookup:
            recovered.append(item)
        elif results.get(key, (False, "?"))[0]:
            recovered.append(item)
        else:
            removed.append(item)
    # 删除仍失败的频道，记录完整对象供第三轮复测恢复
    removed_keys = {(i["category"], i["name"]) for i in removed}
    deleted_channels = []
    for cat in data.get("categories", []):
        kept = []
        for ch in cat["channels"]:
            if (cat["name"], ch["name"]) in removed_keys:
                reason = next((i["reason"] for i in removed
                               if i["category"] == cat["name"] and i["name"] == ch["name"]), "")
                deleted_channels.append({
                    "category": cat["name"],
                    "reason": reason,
                    "channel": ch,
                })
            else:
                kept.append(ch)
        cat["channels"] = kept
    data["categories"] = [c for c in data["categories"] if c["channels"]]
    save_json(args.output, data)
    deleted = {
        "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "channels": deleted_channels,
    }
    save_json(args.deleted, deleted)
    pending["channels"] = []
    save_json(args.pending, pending)
    print()
    print(f"[第二轮] 完成: 复测 {len(to_test)}，恢复正常 {len(recovered)}，删除 {len(removed)}")
    for item in removed:
        print(f"  删除: [{item['category']}] {item['name']}")
    for item in recovered:
        if (item["category"], item["name"]) in lookup:
            print(f"  恢复: [{item['category']}] {item['name']}")
    print(f"已删列表已保存: {args.deleted}（供第三轮复测恢复）")


def run_round3(args):
    if not os.path.exists(args.deleted):
        print("[第三轮] 已删列表不存在，跳过")
        return
    deleted = load_json(args.deleted)
    deleted_list = deleted.get("channels", [])
    if not deleted_list:
        print("[第三轮] 已删列表为空，跳过")
        return
    data = load_json(args.input)
    to_test = {(i["category"], i["channel"]["name"]): i["channel"] for i in deleted_list}
    print(f"[第三轮] 复测 {len(to_test)} 个已删频道，每个 {args.duration} 秒...")
    results = run_tests(to_test, args.duration, args.workers)
    restored, confirmed = [], []
    for item in deleted_list:
        key = (item["category"], item["channel"]["name"])
        if results.get(key, (False, "?"))[0]:
            restored.append(item)
        else:
            confirmed.append(item)
    # 恢复的加回对应分类末尾，分类不存在则创建
    cat_index = {c["name"]: c for c in data.get("categories", [])}
    for item in restored:
        cat_name = item["category"]
        if cat_name not in cat_index:
            new_cat = {"name": cat_name, "channels": []}
            data["categories"].append(new_cat)
            cat_index[cat_name] = new_cat
        cat_index[cat_name]["channels"].append(item["channel"])
    save_json(args.output, data)
    deleted["channels"] = []
    save_json(args.deleted, deleted)
    print()
    print(f"[第三轮] 完成: 复测 {len(to_test)}，恢复加回 {len(restored)}，确认删除 {len(confirmed)}")
    for item in restored:
        print(f"  恢复加回: [{item['category']}] {item['channel']['name']}")
    for item in confirmed:
        print(f"  确认删除: [{item['category']}] {item['channel']['name']}")
    if (restored or confirmed) and args.version_json and args.build_gradle:
        bump_version(args.version_json, args.build_gradle, len(restored), len(confirmed))
    print("频道列表已更新")


def bump_version(vj_path, bg_path, restored_count, confirmed_count=0):
    """第三轮有结果时递增版本号，触发应用内更新提示和重新构建"""
    vj = load_json(vj_path)
    vj["versionCode"] = int(vj.get("versionCode", 0)) + 1
    parts = []
    if restored_count:
        parts.append(f"恢复 {restored_count} 个频道")
    if confirmed_count:
        parts.append(f"确认删除 {confirmed_count} 个无效频道")
    vj["changelog"] = "自动测试：" + "，".join(parts)
    save_json(vj_path, vj)
    with open(bg_path, "r", encoding="utf-8") as f:
        content = f.read()
    content = re.sub(r"versionCode \d+", f"versionCode {vj['versionCode']}", content)
    with open(bg_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"版本号已递增: versionCode {vj['versionCode']}")


def main():
    parser = argparse.ArgumentParser(description="IPTV频道三轮自动测试")
    parser.add_argument("--mode", choices=["round1", "round2", "round3"], required=True)
    parser.add_argument("--input", required=True, help="channels.json路径")
    parser.add_argument("--output", help="round2/round3输出channels.json路径")
    parser.add_argument("--pending", help="待删列表JSON路径(round1/round2)")
    parser.add_argument("--skip-file", help="白名单JSON路径，其中的分类/频道跳过测试(round1)")
    parser.add_argument("--deleted", help="已删列表JSON路径(round2/round3)")
    parser.add_argument("--duration", type=int, default=30, help="测试时长(秒)")
    parser.add_argument("--workers", type=int, default=10, help="并行数")
    parser.add_argument("--version-json", help="round3: version.json路径(递增版本号)")
    parser.add_argument("--build-gradle", help="round3: build.gradle路径(递增版本号)")
    args = parser.parse_args()
    if args.mode == "round1":
        run_round1(args)
    else:
        if not args.output:
            args.output = args.input
        if args.mode == "round2":
            run_round2(args)
        else:
            run_round3(args)


if __name__ == "__main__":
    main()

