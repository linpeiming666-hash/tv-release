# 工作流详解

## auto-test-channels.yml

### 触发方式

1. **定时触发**：每天 UTC 04:00、10:00、12:00（北京时间 12:00、18:00、20:00）
2. **手动触发**：`workflow_dispatch`，可指定 `round` 参数

### 执行流程

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Round 1   │────▶│   Round 2   │────▶│   Round 3   │
│  全量标记    │     │  复测删除    │     │  复测恢复    │
│  (12:00)    │     │  (18:00)    │     │  (20:00)    │
└─────────────┘     └─────────────┘     └─────────────┘
       │                   │                   │
       ▼                   ▼                   ▼
  pending-delete.json  删除失效频道      恢复可用频道
  (待删列表)          deleted.json      递增版本号
                     (已删列表)        构建新 APK
```

### Round 1：全量标记

1. 加载 `channels.json` 和白名单 `test-skip.json`
2. 跳过白名单中的分类和频道
3. 并发测试所有频道（ffmpeg 30 秒）
4. 不能播放的写入 `pending-delete.json`
5. **不删除任何频道**，只标记待删

### Round 2：复测删除

1. 加载 `pending-delete.json` 待删列表
2. 复测每个待删频道（ffmpeg 30 秒）
3. 仍不能播放的：
   - 从 `channels.json` 删除
   - 记录完整频道对象到 `deleted.json`（供第三轮恢复）
4. 恢复正常的：从待删列表移除
5. 清空 `pending-delete.json`

### Round 3：复测恢复 + 构建

1. 加载 `deleted.json` 已删列表
2. 复测每个已删频道（ffmpeg 30 秒）
3. 恢复正常的：加回 `channels.json` 对应分类
4. 递增 `version.json` 和 `build.gradle` 中的 versionCode
5. 如果有变更：
   - 提交并推送代码
   - 构建 APK
   - 上传到 release
   - 发布到 tv-release 仓库

## test_channels.py

### 核心函数

- `test_url(url, duration)`：用 ffmpeg 测试单个 URL
- `test_channel(ch, duration)`：测试频道所有备选 URL，任一成功即通过
- `run_tests(channel_map, duration, workers)`：并发测试所有频道
- `bump_version(vj_path, bg_path, restored, confirmed)`：递增版本号

### 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--mode` | 测试轮次 (round1/round2/round3) | 必填 |
| `--input` | channels.json 路径 | 必填 |
| `--output` | 输出 channels.json 路径 | 同 input |
| `--pending` | 待删列表路径 | - |
| `--deleted` | 已删列表路径 | - |
| `--skip-file` | 白名单路径 | - |
| `--duration` | 测试时长（秒） | 30 |
| `--workers` | 并行数 | 10 |
| `--version-json` | version.json 路径 | - |
| `--build-gradle` | build.gradle 路径 | - |
