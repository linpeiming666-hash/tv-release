---
name: iptv-app-update
description: |
  Android IPTV应用内自动更新功能完整方案：检查版本→多镜像下载→进度显示→速度监控→自动切换→安装APK。
  包含UpdateChecker.java完整源码、FileProvider配置、version.json格式、镜像加速策略。
  已修复：镜像失效、CDN缓存、静默检查不提示、下载完成不弹框等问题。
  触发词：应用内更新、APP自动更新、检查更新、下载安装APK、镜像下载、版本检查、更新排查。
allowed-tools: Bash(python3:*)
---

# IPTV 应用内更新功能

## 核心能力

1. **版本检查**：从GitHub读取version.json，对比versionCode判断是否需要更新
2. **多镜像下载**：GitHub镜像源优先+jsdelivr CDN备选+直连，国内稳定可访问
3. **时间戳破缓存**：version.json检查URL加`?t=时间戳`破CDN缓存
4. **进度显示**：实时显示下载百分比、已下载大小、总大小、下载速度
5. **速度监控自动切换**：5秒内下载不足500KB自动切换下一个镜像源
6. **APK版本验证**：下载后验证APK的versionCode，防止安装旧缓存版本
7. **直接安装**：下载完成后直接调起系统安装器，不弹确认对话框
8. **兼容Android 4.4+**：minSdk 19，FileProvider安全安装

## 工作流

```
APP启动 → checkUpdate(silent=true) → 后台检查version.json（加时间戳破缓存）
  ↓
有新版本 → 弹窗显示更新内容 → 用户点击"立即更新"
  ↓
多镜像下载 → 显示进度条+速度 → 速度太慢自动切换镜像
  ↓
下载完成 → 验证APK版本 → 直接调起系统安装器
  ↓
用户确认安装 → 覆盖安装新版本 → 完成
```

## 集成步骤

### 1. 复制 UpdateChecker.java

将 `assets/UpdateChecker.java` 复制到项目的 Java 源码目录，修改 package 声明。

### 2. 配置 FileProvider

在 `res/xml/` 下创建 `file_paths.xml`（见 assets/file_paths.xml），
在 `AndroidManifest.xml` 中注册 FileProvider。

### 3. 创建 version.json

在GitHub仓库放置 version.json（见 assets/version.json）。

### 4. 调用更新检查

```java
// 启动时静默检查
UpdateChecker.checkUpdate(this, true);

// 用户手动检查（按U键）
UpdateChecker.checkUpdate(this, false);
```

## 镜像源配置（已验证 2026-10-14）

### version.json 检查镜像（优先级从高到低）

| 优先级 | 镜像 | 状态 | 说明 |
|--------|------|------|------|
| 1 | `https://ghproxy.net/https://raw.githubusercontent.com/...` | 可用 | 实时同步，无缓存问题 |
| 2 | `https://gh-proxy.com/https://raw.githubusercontent.com/...` | 可用 | 实时同步 |
| 3 | `https://cdn.jsdelivr.net/gh/USER/REPO@main/tools/version.json` | 可用 | CDN有10-12小时缓存延迟 |
| 4 | `https://fastly.jsdelivr.net/gh/USER/REPO@main/tools/version.json` | 可用 | CDN备选 |
| 5 | `https://raw.githubusercontent.com/...` | 国内被墙 | 最后备选 |

### APK下载镜像

| 优先级 | 镜像 | 状态 |
|--------|------|------|
| 1 | `https://ghproxy.net/` | 可用 |
| 2 | `https://gh-proxy.com/` | 可用 |
| 3 | `https://ghfast.top/` | 不稳定（有时0字节） |
| 4 | 直连GitHub | 国内慢 |

### 已失效镜像（不要使用）

| 镜像 | 失效原因 |
|------|----------|
| `mirror.ghproxy.com` | 连接返回000 |
| `github.moeyy.xyz` | 连接失败 |

## 排查指南

### 问题：APP不显示更新提示

**排查步骤**：

1. **确认当前安装版本**：系统设置→应用管理→查看版本号
2. **确认GitHub上version.json的versionCode**：用浏览器打开version.json
3. **比较版本号**：如果当前版本 >= version.json的versionCode，不提示是正常的
4. **如果当前版本 < version.json的versionCode但不提示**：

**可能原因A：镜像全部失效**
- 旧版APP的UpdateChecker镜像列表可能包含已失效的镜像
- 所有镜像失败后`jsonStr=null`，silent=true不显示提示
- 解决：手动下载安装新版APK，新版有可用镜像列表

**可能原因B：CDN缓存旧版本**
- jsdelivr CDN缓存了旧的version.json，返回的versionCode比安装版本还旧
- 解决：version.json检查URL加时间戳参数`?t=System.currentTimeMillis()`破缓存

**可能原因C：鸡生蛋问题**
- 旧版本镜像失效 → 无法通过app内更新获取新镜像 → 必须手动下载安装一次新版
- 解决：用浏览器手动下载最新APK安装

### 问题：下载完成后不弹安装界面

**可能原因**：Android 8+需在系统设置开启"允许安装未知应用"权限
**解决**：安装前检查`canRequestPackageInstalls()`，跳转授权页

## version.json 格式

```json
{
  "versionCode": 42,
  "versionName": "2.9.28",
  "downloadUrl": "https://github.com/USER/REPO/releases/download/v1.1.0/app.apk",
  "changelog": "1. 新功能\n2. 修复\n3. 优化"
}
```

## 资源导航

| 资源 | 路径 | 用途 |
|------|------|------|
| UpdateChecker源码 | assets/UpdateChecker.java | 完整的更新检查+下载+安装代码（已修复） |
| FileProvider配置 | assets/file_paths.xml | APK文件共享配置 |
| 版本文件模板 | assets/version.json | version.json格式模板 |
| 集成指南 | references/integration-guide.md | 详细集成步骤+排查指南 |
