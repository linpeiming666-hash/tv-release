# IPTV 应用内更新集成指南

## 一、集成步骤

### 1. 添加 UpdateChecker.java

将 `assets/UpdateChecker.java` 复制到项目源码目录，修改 package 声明。

### 2. 配置 FileProvider

**res/xml/file_paths.xml**：
```xml
<?xml version="1.0" encoding="utf-8"?>
<paths>
    <external-files-path name="apk" path="." />
</paths>
```

**AndroidManifest.xml** 添加：
```xml
<provider
    android:name="androidx.core.content.FileProvider"
    android:authorities="${applicationId}.fileprovider"
    android:exported="false"
    android:grantUriPermissions="true">
    <meta-data
        android:name="android.support.FILE_PROVIDER_PATHS"
        android:resource="@xml/file_paths" />
</provider>
```

### 3. 创建 version.json

在GitHub仓库 `tools/version.json` 放置：
```json
{
  "versionCode": 42,
  "versionName": "2.9.28",
  "downloadUrl": "https://github.com/USER/REPO/releases/download/v1.1.0/app.apk",
  "changelog": "1. 新功能\n2. 修复"
}
```

### 4. 调用更新检查

```java
// APP启动时静默检查（onCreate中）
UpdateChecker.checkUpdate(this, true);

// 用户手动检查（按U键）
UpdateChecker.checkUpdate(this, false);
```

## 二、关键技术点

### 2.1 时间戳破CDN缓存

version.json检查URL必须加时间戳参数，否则CDN缓存旧版本：
```java
String cacheBuster = "?t=" + System.currentTimeMillis();
for (String url : new String[]{MIRROR1 + cacheBuster, MIRROR2 + cacheBuster, ...}) {
```

### 2.2 镜像优先级

- **version.json检查**：ghproxy.net（实时同步）优先 > jsdelivr CDN（有缓存延迟）备选
- **APK下载**：ghproxy.net > gh-proxy.com > ghfast.top > 直连

### 2.3 下载完成后直接安装

不弹确认对话框，直接调用installApk()：
```java
handler.post(() -> {
    dialog.dismiss();
    installApk(activity, finalFile);
});
```

### 2.4 Android 8+安装权限

```java
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
    if (!activity.getPackageManager().canRequestPackageInstalls()) {
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
        intent.setData(Uri.parse("package:" + activity.getPackageName()));
        activity.startActivity(intent);
        return;
    }
}
```

## 三、排查指南

### 3.1 APP不显示更新提示

| 步骤 | 操作 |
|------|------|
| 1 | 确认当前安装版本号（系统设置→应用管理） |
| 2 | 确认GitHub上version.json的versionCode |
| 3 | 如果当前版本 < versionCode但不提示 → 镜像失效或CDN缓存 |
| 4 | 手动下载安装最新APK一次，新版有修复后的镜像列表 |

### 3.2 常见问题

| 问题 | 原因 | 解决 |
|------|------|------|
| 静默检查失败不提示 | silent=true | 正常行为，检查失败不显示 |
| CDN返回旧版本 | CDN缓存延迟 | URL加时间戳破缓存 |
| 所有镜像失败 | 镜像失效 | 手动安装新版获取新镜像列表 |
| 下载后不弹安装 | Android 8+权限 | 检查canRequestPackageInstalls() |
| 下载0字节 | ghfast.top不稳定 | 切换ghproxy.net镜像 |

## 四、版本号管理

### 4.1 递增版本号

每次发布新版本：
1. build.gradle: `versionCode` +1, `versionName` 更新
2. version.json: 同步更新 versionCode 和 versionName
3. 构建APK上传到GitHub Release

### 4.2 验证版本号

```bash
# 用androguard验证Release APK真实versionCode
pip3 install androguard
python3 -c "
from androguard.core.apk import APK
a = APK('app.apk')
print(f'versionCode: {a.get_androidversion_code()}')
print(f'versionName: {a.get_androidversion_name()}')
"
```

## 五、已验证可用镜像（2026-10-14）

### 可用
- `ghproxy.net` — 实时同步，无缓存问题
- `gh-proxy.com` — 实时同步
- `cdn.jsdelivr.net` — CDN，有10-12小时缓存延迟
- `fastly.jsdelivr.net` — CDN备选

### 已失效
- `mirror.ghproxy.com` — 连接返回000
- `github.moeyy.xyz` — 连接失败
