# APP 更新功能问题排查与修复记录

## 问题总览

| # | 问题 | 根因 | 修复 |
|---|------|------|------|
| 1 | APP 永远检查不到更新 | VERSION_URL 指向私人仓库 tv-proxy，镜像返回 404 | 改为公开仓库 tv-release |
| 2 | 循环下载（进度条反复从0开始） | 速度检查逻辑：10秒内不足500KB就切换镜像 | 删除速度检查，加大 readTimeout |
| 3 | 下载的 APK 是旧版本 2.9.11 | 更新了错误的 build.gradle 路径 (`app/build.gradle` 而非 `apk-native/app/build.gradle`) | 更新正确路径的 build.gradle |
| 4 | 下载完一直反复下载不安装 | CDN 缓存旧版 APK，版本验证 `apkVersionCode <= currentCode` 拒绝同版本 | 清除 CDN 缓存，downloadUrl 改为 GitHub release |
| 5 | version.json 不生效 | 只更新了 tv-proxy 的 version.json，没更新 tv-release 的 | 同时更新两个仓库的 version.json |

---

## 问题 1：APP 永远检查不到更新

### 症状
APP 打开后不提示更新，手动检查更新也提示"检查更新失败"。

### 根因
`UpdateChecker.java` 中所有版本检查 URL 都指向 **tv-proxy（私人仓库）**：
```java
// 错误 - 私人仓库，镜像无法访问
private static final String VERSION_URL = "https://raw.githubusercontent.com/linpeiming666-hash/tv-proxy/main/tools/version.json";
```
镜像（ghproxy.net、gh-proxy.com 等）无法访问私人仓库内容，返回 404，导致 `jsonStr == null`，APP 认为"检查更新失败"。

### 修复
将 VERSION_URL 改为 **tv-release（公开仓库）**，并使用 jsdelivr CDN 作为第一优先级：
```java
// 正确 - 公开仓库，镜像可访问
private static final String VERSION_URL = "https://cdn.jsdelivr.net/gh/linpeiming666-hash/tv-release@main/version.json";
private static final String VERSION_URL_MIRROR1 = "https://fastly.jsdelivr.net/gh/linpeiming666-hash/tv-release@main/version.json";
private static final String VERSION_URL_MIRROR2 = "https://gh-proxy.com/https://raw.githubusercontent.com/linpeiming666-hash/tv-release/main/version.json";
```

---

## 问题 2：循环下载（进度条反复从 0 开始）

### 症状
点击"立即更新"后，下载进度条到 2% 左右又回到 0%，不断重复，无法完成下载。

### 根因
代码中有**速度检查逻辑**：
```java
// 问题代码 - 10秒内不足500KB就切换镜像
if (now - startTime > 10000 && downloaded < 500 * 1024) {
    tooSlow = true;
    break;  // 切换到下一个镜像，从 0% 重新开始
}
```
用户网络速度约 12KB/s，10 秒只下载 120KB < 500KB，每次都触发切换。所有镜像都很慢，所以不断切换、从 0% 重新开始，形成**无限循环**。

### 修复
**删除速度检查逻辑**，让下载慢慢完成；将 `readTimeout` 从 15 秒改为 60 秒：
```java
// 修复 - 不检查速度，加大超时
conn.setReadTimeout(60000);  // 原 15 秒
// 删除 tooSlow 相关代码
```

---

## 问题 3：下载的 APK 是旧版本 2.9.11

### 症状
构建成功，但下载安装后发现版本仍然是 2.9.11 (versionCode=25)，不是 2.9.48 (versionCode=63)。

### 根因
仓库中有**两个 build.gradle 文件**：
- `app/build.gradle` — 根目录下的（错误地更新了这个）
- `apk-native/app/build.gradle` — **构建工作流实际使用的这个**

一直通过 GitHub API 更新 `app/build.gradle` 的版本号，但构建工作流 checkout 的是 `apk-native/app/build.gradle`，所以构建出来的 APK 一直是旧版本。

### 修复
更新正确路径的 build.gradle：
```bash
# 错误路径
PUT /repos/.../contents/app/build.gradle

# 正确路径
PUT /repos/.../contents/apk-native/app/build.gradle
```

### 验证方法
在构建工作流中添加打印版本号的步骤：
```yaml
- name: Print build.gradle version
  run: |
    echo "=== build.gradle content ==="
    cat apk-native/app/build.gradle
    grep -E "versionCode|versionName" apk-native/app/build.gradle
```

---

## 问题 4：下载完一直反复下载不安装

### 症状
APK 下载到 100% 后不弹安装界面，又重新开始下载，反复循环。

### 根因
1. **jsdelivr CDN 缓存了旧版本 APK**（versionCode=63）
2. **版本验证逻辑拒绝同版本 APK**：
```java
// 问题代码 - 下载的版本 <= 当前版本就拒绝
if (apkVersionCode > 0 && apkVersionCode <= currentCode) {
    errorMsg = "镜像返回旧版本(v" + apkVersionCode + ")";
    continue;  // 切换到下一个镜像，又下载旧版本...
}
```
CDN 返回旧版本 APK (63)，验证发现 `63 <= 63`（当前也是 63），拒绝安装，切换镜像。所有镜像都缓存了旧版本，全部验证失败，形成循环。

### 修复
1. **清除 CDN 缓存**：`curl https://purge.jsdelivr.net/gh/.../cloud-tv-native.apk`
2. **downloadUrl 改为 GitHub release**（不经过 CDN 缓存）：
```json
{
  "downloadUrl": "https://github.com/linpeiming666-hash/tv-release/releases/download/v1.1.1/cloud-tv-native.apk"
}
```
3. **下载源优先级调整**：CDN → GitHub release 通过镜像 → GitHub release 直连

---

## 问题 5：version.json 不生效

### 症状
更新了 version.json 中的 versionCode，但 APP 检查更新仍然提示旧版本。

### 根因
**只更新了 tv-proxy 的 version.json，没有更新 tv-release 的 version.json**。

APP 的 VERSION_URL 指向 tv-release 仓库的 version.json，但只更新了 tv-proxy 仓库的 version.json。

### 修复
同时更新两个仓库的 version.json：
```bash
# tv-proxy（源码仓库）
PUT /repos/.../tv-proxy/contents/tools/version.json

# tv-release（发布仓库，APP 实际读取的）
PUT /repos/.../tv-release/contents/version.json
```

---

## 最终修复版 UpdateChecker.java 关键设计

### 版本检查
- **URL 优先级**：jsdelivr CDN → fastly CDN → gh-proxy.com → ghproxy.net → raw.githubusercontent.com
- **时间戳破缓存**：`?t=System.currentTimeMillis()`
- **超时**：连接 8 秒，读取 8 秒

### APK 下载
- **下载源优先级**：CDN1 → CDN2 → gh-proxy.com + release → ghproxy.net + release → ghfast.top + release → release 直连
- **无速度检查**：慢速下载也能完成（12KB/s 下载 4.5MB 约需 6 分钟）
- **readTimeout 60 秒**：避免慢速下载超时中断
- **取消按钮**：用户可随时取消
- **APK 版本验证**：下载后检查 versionCode，旧版本自动跳过
- **安装权限检查**：Android 8+ 检查 `canRequestPackageInstalls()`

### 关键教训
1. **版本检查 URL 必须指向公开仓库**，私人仓库镜像无法访问
2. **不要有速度检查逻辑**，慢速下载也要让用户等完成
3. **更新文件时确认正确路径**，仓库中可能有同名文件
4. **CDN 会缓存二进制文件**，更新 APK 后要清除缓存
5. **version.json 要同时更新两个仓库**（源码仓库 + 发布仓库）
