package com.lpm.tvlive;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.content.pm.PackageInfoCompat;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class UpdateChecker {
    private static final String VERSION_URL = "https://cdn.jsdelivr.net/gh/linpeiming666-hash/tv-release@main/version.json";
    private static final String VERSION_URL_MIRROR1 = "https://fastly.jsdelivr.net/gh/linpeiming666-hash/tv-release@main/version.json";
    private static final String VERSION_URL_MIRROR2 = "https://gh-proxy.com/https://raw.githubusercontent.com/linpeiming666-hash/tv-release/main/version.json";
    private static final String VERSION_URL_MIRROR3 = "https://ghproxy.net/https://raw.githubusercontent.com/linpeiming666-hash/tv-release/main/version.json";
    private static final String VERSION_URL_MIRROR4 = "https://raw.githubusercontent.com/linpeiming666-hash/tv-release/main/version.json";

    private static final String CDN_URL1 = "https://cdn.jsdelivr.net/gh/linpeiming666-hash/tv-release@main/cloud-tv-native.apk";
    private static final String CDN_URL2 = "https://fastly.jsdelivr.net/gh/linpeiming666-hash/tv-release@main/cloud-tv-native.apk";
    private static final String APK_MIRROR1 = "https://ghproxy.net/";
    private static final String APK_MIRROR2 = "https://gh-proxy.com/";
    private static final String APK_MIRROR3 = "https://ghfast.top/";

    public static void checkUpdate(Activity activity, boolean silent) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            String result = null;
            String cacheBuster = "?t=" + System.currentTimeMillis();
            for (String url : new String[]{VERSION_URL + cacheBuster, VERSION_URL_MIRROR1 + cacheBuster, VERSION_URL_MIRROR2 + cacheBuster, VERSION_URL_MIRROR3 + cacheBuster, VERSION_URL_MIRROR4 + cacheBuster}) {
                try {
                    URL u = new URL(url);
                    HttpURLConnection conn = (HttpURLConnection) u.openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                    if (conn.getResponseCode() == 200) {
                        InputStream is = conn.getInputStream();
                        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                        byte[] tmp = new byte[8192];
                        int n;
                        while ((n = is.read(tmp)) != -1) bos.write(tmp, 0, n);
                        is.close();
                        result = bos.toString("UTF-8");
                        break;
                    }
                } catch (Exception e) {
                }
            }
            final String jsonStr = result;
            handler.post(() -> {
                if (jsonStr == null) {
                    if (!silent) Toast.makeText(activity, "检查更新失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    JSONObject json = new JSONObject(jsonStr);
                    int latestVersion = json.getInt("versionCode");
                    String versionName = json.getString("versionName");
                    String downloadUrl = json.getString("downloadUrl");
                    String changelog = json.optString("changelog", "");

                    int currentVersion = (int) PackageInfoCompat.getLongVersionCode(
                            activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0));

                    if (latestVersion > currentVersion) {
                        showUpdateDialog(activity, versionName, latestVersion, downloadUrl, changelog);
                    } else {
                        if (!silent) Toast.makeText(activity, "已是最新版本 v" + versionName, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    if (!silent) Toast.makeText(activity, "解析版本信息失败", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private static void showUpdateDialog(Activity activity, String newVersion, int newVersionCode, String downloadUrl, String changelog) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("发现新版本 v" + newVersion);
        String msg = "点击更新下载安装\n\n更新内容:\n" + changelog;
        builder.setPositiveButton("立即更新", (d, w) -> downloadAndInstall(activity, downloadUrl, newVersionCode));
        builder.setNegativeButton("稍后再说", null);
        builder.show();
    }

    private static void downloadAndInstall(Activity activity, String downloadUrl, int expectedVersionCode) {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 30, 40, 30);

        ProgressBar progressBar = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout.addView(progressBar, pbLp);

        TextView progressText = new TextView(activity);
        progressText.setText("准备下载...");
        progressText.setGravity(Gravity.CENTER);
        progressText.setPadding(0, 16, 0, 0);
        LinearLayout.LayoutParams ptLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout.addView(progressText, ptLp);

        TextView speedText = new TextView(activity);
        speedText.setText("");
        speedText.setGravity(Gravity.CENTER);
        speedText.setPadding(0, 8, 0, 0);
        speedText.setTextColor(0xFF888888);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout.addView(speedText, stLp);

        AtomicBoolean cancelled = new AtomicBoolean(false);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("正在下载更新")
                .setView(layout)
                .setCancelable(false)
                .setNegativeButton("取消", (d, w) -> {
                    cancelled.set(true);
                    d.dismiss();
                })
                .create();
        dialog.show();

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            String cacheBuster = "?t=" + System.currentTimeMillis();
            String[] urls = new String[]{
                CDN_URL1 + cacheBuster,
                CDN_URL2 + cacheBuster,
                APK_MIRROR2 + downloadUrl + cacheBuster,
                APK_MIRROR1 + downloadUrl + cacheBuster,
                APK_MIRROR3 + downloadUrl + cacheBuster,
                downloadUrl + cacheBuster,
            };
            String[] names = {"CDN1", "CDN2", "镜像1", "镜像2", "镜像3", "直连"};

            boolean success = false;
            String errorMsg = null;

            for (int urlIdx = 0; urlIdx < urls.length; urlIdx++) {
                if (cancelled.get()) {
                    handler.post(() -> Toast.makeText(activity, "下载已取消", Toast.LENGTH_SHORT).show());
                    return;
                }

                final String mName = names[urlIdx];
                handler.post(() -> {
                    progressText.setText("通过" + mName + "下载中...");
                    speedText.setText("");
                    progressBar.setProgress(0);
                    progressBar.setIndeterminate(false);
                });

                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urls[urlIdx]);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(60000);
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                    conn.setInstanceFollowRedirects(true);

                    int responseCode = conn.getResponseCode();
                    if (responseCode != 200) {
                        conn.disconnect();
                        errorMsg = "HTTP " + responseCode;
                        continue;
                    }

                    int totalSize = conn.getContentLength();
                    File outputFile = new File(activity.getExternalFilesDir(null), "cloud-tv-update.apk");
                    if (outputFile.exists()) outputFile.delete();

                    InputStream is = conn.getInputStream();
                    FileOutputStream fos = new FileOutputStream(outputFile);
                    byte[] buf = new byte[262144];
                    int len;
                    long downloaded = 0;
                    long lastTime = System.currentTimeMillis();
                    long lastDownloaded = 0;

                    while ((len = is.read(buf)) != -1) {
                        if (cancelled.get()) {
                            fos.close();
                            is.close();
                            conn.disconnect();
                            outputFile.delete();
                            handler.post(() -> Toast.makeText(activity, "下载已取消", Toast.LENGTH_SHORT).show());
                            return;
                        }

                        fos.write(buf, 0, len);
                        downloaded += len;

                        long now = System.currentTimeMillis();
                        if (now - lastTime > 300) {
                            long speed = (downloaded - lastDownloaded) * 1000 / (now - lastTime);
                            lastTime = now;
                            lastDownloaded = downloaded;

                            final long d = downloaded;
                            final long t = totalSize;
                            final long s = speed;
                            final int p = (totalSize > 0) ? (int)(d * 100 / t) : -1;

                            handler.post(() -> {
                                if (p >= 0) {
                                    progressBar.setProgress(p);
                                    progressText.setText(p + "%  (" + formatSize(d) + " / " + formatSize(t) + ")");
                                } else {
                                    progressText.setText("已下载 " + formatSize(d));
                                }
                                speedText.setText(formatSpeed(s));
                            });
                        }
                    }
                    fos.close();
                    is.close();
                    conn.disconnect();

                    if (outputFile.length() < 100000) {
                        errorMsg = "下载文件过小(" + outputFile.length() + "B)";
                        continue;
                    }

                    int apkVersionCode = getApkVersionCode(activity, outputFile);
                    int currentCode = getCurrentVersionCode(activity);
                    if (apkVersionCode > 0 && apkVersionCode <= currentCode) {
                        errorMsg = "镜像返回旧版本(v" + apkVersionCode + ")";
                        continue;
                    }

                    final File finalFile = outputFile;
                    handler.post(() -> {
                        dialog.dismiss();
                        installApk(activity, finalFile);
                    });
                    success = true;
                    break;

                } catch (Exception e) {
                    errorMsg = e.getMessage();
                    if (conn != null) {
                        try { conn.disconnect(); } catch (Exception e2) {}
                    }
                }
            }

            if (!success && !cancelled.get()) {
                final String msg = errorMsg;
                handler.post(() -> {
                    dialog.dismiss();
                    new AlertDialog.Builder(activity)
                            .setTitle("下载失败")
                            .setMessage("原因: " + msg + "\n\n请手动下载安装:\n" + CDN_URL1)
                            .setPositiveButton("复制链接", (d, w) -> {
                                android.content.ClipboardManager clip = (android.content.ClipboardManager)
                                        activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                                clip.setPrimaryClip(android.content.ClipData.newPlainText("url", CDN_URL1));
                                Toast.makeText(activity, "链接已复制到剪贴板", Toast.LENGTH_SHORT).show();
                            })
                            .setNegativeButton("确定", null)
                            .show();
                });
            }
        });
    }

    private static int getApkVersionCode(Activity activity, File apkFile) {
        try {
            PackageManager pm = activity.getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(apkFile.getAbsolutePath(), 0);
            if (pi != null) {
                return (int) PackageInfoCompat.getLongVersionCode(pi);
            }
        } catch (Exception e) {
        }
        return 0;
    }

    private static int getCurrentVersionCode(Activity activity) {
        try {
            return (int) PackageInfoCompat.getLongVersionCode(
                    activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0));
        } catch (Exception e) {
            return 0;
        }
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024 * 1024) return String.format("%.1fKB", bytes / 1024.0);
        return String.format("%.1fMB", bytes / 1024.0 / 1024.0);
    }

    private static String formatSpeed(long bytesPerSec) {
        if (bytesPerSec < 1024) return bytesPerSec + "B/s";
        if (bytesPerSec < 1024 * 1024) return String.format("%.1fKB/s", bytesPerSec / 1024.0);
        return String.format("%.1fMB/s", bytesPerSec / 1024.0 / 1024.0);
    }

    private static void installApk(Activity activity, File apkFile) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (!activity.getPackageManager().canRequestPackageInstalls()) {
                    Toast.makeText(activity, "请先开启【允许安装未知应用】权限", Toast.LENGTH_LONG).show();
                    try {
                        Intent permIntent = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + activity.getPackageName()));
                        permIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        activity.startActivity(permIntent);
                    } catch (Exception e2) {
                        try {
                            activity.startActivity(new Intent(android.provider.Settings.ACTION_SECURITY_SETTINGS));
                        } catch (Exception e3) {
                        }
                    }
                    return;
                }
            }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", apkFile);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                uri = Uri.fromFile(apkFile);
            }
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(activity, "无法启动安装: " + e.getMessage(), Toast.LENGTH_LONG).show();
            try {
                Intent fallback = new Intent(android.content.Intent.ACTION_INSTALL_PACKAGE);
                Uri uri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", apkFile);
                    fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } else {
                    uri = Uri.fromFile(apkFile);
                }
                fallback.setDataAndType(uri, "application/vnd.android.package-archive");
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(fallback);
            } catch (Exception e2) {
                Toast.makeText(activity, "安装失败，请手动安装下载的APK文件", Toast.LENGTH_LONG).show();
            }
        }
    }
}
